
import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";

const App = () => {
  const [meals, setMeals] = useState({
    kahvalti: [],
    ogle: [],
    aksam: [],
    diger: []
  });

  const [input, setInput] = useState("");
  const [category, setCategory] = useState("kahvalti");

  const handleAdd = () => {
    const [name, calorie] = input.split("-").map(item => item.trim());
    if (name && calorie && !isNaN(calorie)) {
      setMeals(prev => ({
        ...prev,
        [category]: [...prev[category], { name, calorie: parseInt(calorie) }]
      }));
      setInput("");
    }
  };

  const totalCalories = Object.values(meals)
    .flat()
    .reduce((acc, cur) => acc + cur.calorie, 0);

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 font-sans">
      <h1 className="text-3xl font-bold mb-4">Kalori Takip</h1>
      <div className="mb-4">
        <select
          value={category}
          onChange={e => setCategory(e.target.value)}
          className="bg-gray-800 p-2 rounded mr-2"
        >
          <option value="kahvalti">Kahvaltı</option>
          <option value="ogle">Öğle Yemeği</option>
          <option value="aksam">Akşam Yemeği</option>
          <option value="diger">Diğer</option>
        </select>
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Yemek - Kalori"
          className="bg-gray-800 p-2 rounded mr-2"
        />
        <button onClick={handleAdd} className="bg-green-600 p-2 rounded">
          Ekle
        </button>
      </div>

      {Object.entries(meals).map(([key, items]) => (
        <div key={key} className="mb-4">
          <h2 className="text-xl font-semibold capitalize">{key}</h2>
          <ul>
            {items.map((item, idx) => (
              <li key={idx} className="flex justify-between border-b border-gray-700 py-1">
                <span>{item.name}</span>
                <span>{item.calorie} kal</span>
              </li>
            ))}
          </ul>
        </div>
      ))}

      <div className="text-2xl font-bold mt-6">
        Toplam Kalori: {totalCalories} kal
      </div>
    </div>
  );
};

const root = createRoot(document.getElementById("root"));
root.render(<App />);
