
let totalCalories = 0, protein = 0, carbs = 0, fat = 0, water = 0;

function updateSummary() {
    document.getElementById('cal-summary').innerText = `Toplam Kalori: ${totalCalories} kcal`;
    document.getElementById('macro-summary').innerText = `Protein: ${protein}g | Karbonhidrat: ${carbs}g | Yağ: ${fat}g`;
}

function addFood() {
    const name = document.getElementById('food-name').value;
    const cal = parseInt(document.getElementById('food-calories').value);
    const pro = parseInt(document.getElementById('food-protein').value);
    const car = parseInt(document.getElementById('food-carbs').value);
    const f = parseInt(document.getElementById('food-fat').value);

    if (!name || isNaN(cal)) return;

    totalCalories += cal;
    protein += pro || 0;
    carbs += car || 0;
    fat += f || 0;

    const li = document.createElement('li');
    li.textContent = `${name} - ${cal} kcal`;
    document.getElementById('food-list').appendChild(li);

    updateSummary();
}

function addWater() {
    water++;
    document.getElementById('water-count').innerText = `İçilen Su: ${water} bardak`;
}

function addActivity() {
    const name = document.getElementById('activity-name').value;
    const cal = parseInt(document.getElementById('activity-calories').value);

    if (!name || isNaN(cal)) return;

    totalCalories -= cal;

    const li = document.createElement('li');
    li.textContent = `${name} - ${cal} kcal yakıldı`;
    document.getElementById('activity-list').appendChild(li);

    updateSummary();
}
